[CmdletBinding()]
param(
    [Parameter(Mandatory = $true)]
    [string]$InputPath,

    [Parameter(Mandatory = $true)]
    [string]$OutputPath
)

$ErrorActionPreference = 'Stop'
Set-StrictMode -Version Latest

Add-Type -AssemblyName PresentationCore

$resolvedInput = (Resolve-Path -LiteralPath $InputPath).Path
$resolvedOutput = [System.IO.Path]::GetFullPath($OutputPath)
$outputDirectory = [System.IO.Path]::GetDirectoryName($resolvedOutput)
if (-not [string]::IsNullOrWhiteSpace($outputDirectory)) {
    [System.IO.Directory]::CreateDirectory($outputDirectory) | Out-Null
}

$source = [System.Windows.Media.Imaging.BitmapImage]::new()
$source.BeginInit()
$source.CacheOption = [System.Windows.Media.Imaging.BitmapCacheOption]::OnLoad
$source.UriSource = [Uri]::new($resolvedInput)
$source.EndInit()
$source.Freeze()

$sizes = @(256, 128, 64, 48, 32, 24, 16)
$images = foreach ($size in $sizes) {
    $scaleX = $size / $source.PixelWidth
    $scaleY = $size / $source.PixelHeight
    $transform = [System.Windows.Media.ScaleTransform]::new($scaleX, $scaleY)
    $resized = [System.Windows.Media.Imaging.TransformedBitmap]::new($source, $transform)
    $resized.Freeze()

    $encoder = [System.Windows.Media.Imaging.PngBitmapEncoder]::new()
    $encoder.Frames.Add([System.Windows.Media.Imaging.BitmapFrame]::Create($resized))
    $stream = [System.IO.MemoryStream]::new()
    try {
        $encoder.Save($stream)
        [PSCustomObject]@{
            Size = $size
            Data = $stream.ToArray()
        }
    }
    finally {
        $stream.Dispose()
    }
}

$file = [System.IO.FileStream]::new(
    $resolvedOutput,
    [System.IO.FileMode]::Create,
    [System.IO.FileAccess]::Write,
    [System.IO.FileShare]::None)
$writer = [System.IO.BinaryWriter]::new($file)

try {
    $writer.Write([UInt16]0)              # Reserved
    $writer.Write([UInt16]1)              # ICO image type
    $writer.Write([UInt16]$images.Count)

    $offset = 6 + (16 * $images.Count)
    foreach ($image in $images) {
        $dimension = if ($image.Size -eq 256) { 0 } else { $image.Size }
        $writer.Write([byte]$dimension)
        $writer.Write([byte]$dimension)
        $writer.Write([byte]0)             # Palette size
        $writer.Write([byte]0)             # Reserved
        $writer.Write([UInt16]1)            # Color planes
        $writer.Write([UInt16]32)           # Bits per pixel
        $writer.Write([UInt32]$image.Data.Length)
        $writer.Write([UInt32]$offset)
        $offset += $image.Data.Length
    }

    foreach ($image in $images) {
        $writer.Write([byte[]]$image.Data)
    }
}
finally {
    $writer.Dispose()
    $file.Dispose()
}

Write-Host "Ikona vytvořena: $resolvedOutput"

