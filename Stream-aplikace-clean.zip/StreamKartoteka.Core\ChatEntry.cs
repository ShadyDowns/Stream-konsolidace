namespace StreamKartoteka.Core;

public sealed class ChatEntry
{
    public ChatEntry(
        string id,
        string userLogin,
        string displayName,
        string text,
        DateTimeOffset sentAt,
        string colorHex)
    {
        Id = id;
        UserLogin = userLogin;
        DisplayName = displayName;
        Text = text;
        SentAt = sentAt;
        ColorHex = colorHex;
    }

    public string Id { get; }
    public string UserLogin { get; }
    public string DisplayName { get; }
    public string Text { get; }
    public DateTimeOffset SentAt { get; }
    public string ColorHex { get; }
    public bool IsHandled { get; internal set; }
}

