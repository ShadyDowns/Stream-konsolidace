using System.Globalization;
using System.Text;
using System.Text.RegularExpressions;

namespace StreamKartoteka.Core;

public static partial class IrcMessageParser
{
    private static readonly string[] FallbackColors =
    [
        "#8B5CF6", "#14B8A6", "#F97316", "#EC4899",
        "#3B82F6", "#84CC16", "#EAB308", "#F43F5E"
    ];

    public static bool TryParsePrivMsg(string line, out ChatEntry? message)
    {
        message = null;
        if (string.IsNullOrWhiteSpace(line))
        {
            return false;
        }

        var match = PrivMsgRegex().Match(line);
        if (!match.Success)
        {
            return false;
        }

        var tags = ParseTags(match.Groups["tags"].Value);
        var login = match.Groups["login"].Value;
        var displayName = tags.TryGetValue("display-name", out var taggedName)
            ? UnescapeTag(taggedName)
            : login;
        var text = match.Groups["text"].Value;
        var id = tags.GetValueOrDefault("id") ?? Guid.NewGuid().ToString("N");
        var color = NormalizeColor(tags.GetValueOrDefault("color"), login);
        var sentAt = ParseTimestamp(tags.GetValueOrDefault("tmi-sent-ts"));

        message = new ChatEntry(id, login, displayName, text, sentAt, color);
        return true;
    }

    public static IReadOnlyDictionary<string, string> ParseTags(string rawTags)
    {
        var result = new Dictionary<string, string>(StringComparer.Ordinal);
        if (string.IsNullOrEmpty(rawTags))
        {
            return result;
        }

        foreach (var pair in rawTags.Split(';'))
        {
            var equalsIndex = pair.IndexOf('=');
            if (equalsIndex < 0)
            {
                result[pair] = string.Empty;
                continue;
            }

            result[pair[..equalsIndex]] = pair[(equalsIndex + 1)..];
        }

        return result;
    }

    public static string UnescapeTag(string value)
    {
        if (!value.Contains('\\'))
        {
            return value;
        }

        var builder = new StringBuilder(value.Length);
        for (var i = 0; i < value.Length; i++)
        {
            if (value[i] != '\\' || i + 1 >= value.Length)
            {
                builder.Append(value[i]);
                continue;
            }

            i++;
            builder.Append(value[i] switch
            {
                's' => ' ',
                ':' => ';',
                'r' => '\r',
                'n' => '\n',
                '\\' => '\\',
                _ => value[i]
            });
        }

        return builder.ToString();
    }

    private static DateTimeOffset ParseTimestamp(string? milliseconds)
    {
        if (long.TryParse(milliseconds, NumberStyles.None, CultureInfo.InvariantCulture, out var parsed))
        {
            try
            {
                return DateTimeOffset.FromUnixTimeMilliseconds(parsed).ToLocalTime();
            }
            catch (ArgumentOutOfRangeException)
            {
                // Fall through to the local receive time.
            }
        }

        return DateTimeOffset.Now;
    }

    private static string NormalizeColor(string? color, string login)
    {
        if (!string.IsNullOrWhiteSpace(color) && HexColorRegex().IsMatch(color))
        {
            return color.ToUpperInvariant();
        }

        var hash = 17;
        foreach (var character in login)
        {
            hash = unchecked((hash * 31) + char.ToLowerInvariant(character));
        }

        return FallbackColors[(hash & int.MaxValue) % FallbackColors.Length];
    }

    [GeneratedRegex(@"^(?:@(?<tags>[^ ]+) )?:(?<login>[^! ]+)!.*? PRIVMSG #[^ ]+ :(?<text>.*)$", RegexOptions.CultureInvariant)]
    private static partial Regex PrivMsgRegex();

    [GeneratedRegex("^#[0-9A-Fa-f]{6}$", RegexOptions.CultureInvariant)]
    private static partial Regex HexColorRegex();
}

