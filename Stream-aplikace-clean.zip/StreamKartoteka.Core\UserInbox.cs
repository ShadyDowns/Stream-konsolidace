namespace StreamKartoteka.Core;

public sealed class UserInbox
{
    private readonly List<ChatEntry> _messages = [];

    internal UserInbox(string login, string displayName, string colorHex)
    {
        Login = login;
        DisplayName = displayName;
        ColorHex = colorHex;
    }

    public string Login { get; }
    public string DisplayName { get; internal set; }
    public string ColorHex { get; internal set; }
    public IReadOnlyList<ChatEntry> Messages => _messages;
    public int PendingCount => _messages.Count(message => !message.IsHandled);
    public ChatEntry? LatestMessage => _messages.Count == 0 ? null : _messages[^1];

    internal void Add(ChatEntry message)
    {
        DisplayName = message.DisplayName;
        ColorHex = message.ColorHex;
        _messages.Add(message);
    }
}

